import { User } from ".";

export interface UserResults {
  user: User;
  score: number;
}
