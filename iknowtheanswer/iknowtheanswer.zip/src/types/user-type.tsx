export interface User {
  id: string;
  avatar: string;
  displayName: string;
  username: string;
}
